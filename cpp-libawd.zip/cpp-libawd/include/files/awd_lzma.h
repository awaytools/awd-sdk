#ifndef _LIBAWD_AWD_LZMA_H
#define _LIBAWD_AWD_LZMA_H
#ifdef USECOMPRESSION
void *      awd_SzAlloc(void *, size_t);
void        awd_SzFree(void *, void *);
#endif
#endif
